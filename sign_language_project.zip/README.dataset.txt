# sign language project > 2024-03-07 2:23pm
https://universe.roboflow.com/raviflow/sign-language-project-jbxhz

Provided by a Roboflow user
License: CC BY 4.0

